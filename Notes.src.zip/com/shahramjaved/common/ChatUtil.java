/*    */ package com.shahramjaved.common;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ 
/*    */ public final class ChatUtil
/*    */ {
/*  6 */   private static final DecimalFormat commaFormat = new DecimalFormat("#,###");
/*    */ 
/*    */   public static String toCommaString(int integer)
/*    */   {
/* 12 */     return commaFormat.format(integer);
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.common.ChatUtil
 * JD-Core Version:    0.6.2
 */
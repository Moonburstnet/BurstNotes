/*    */ package com.shahramjaved.common;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map.Entry;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.PlayerInventory;
/*    */ 
/*    */ public class InventoryUtil
/*    */ {
/*    */   public static void addItemsOrDrop(Player p, ItemStack[] items)
/*    */   {
/* 11 */     HashMap nope = p.getInventory().addItem(items);
/* 12 */     for (Map.Entry entry : nope.entrySet())
/* 13 */       p.getWorld().dropItemNaturally(p.getLocation(), (ItemStack)entry.getValue());
/*    */   }
/*    */ 
/*    */   public static void emptyCursor(Player p)
/*    */   {
/* 18 */     p.setItemOnCursor(ItemUtil.emptyItem());
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.common.InventoryUtil
 * JD-Core Version:    0.6.2
 */
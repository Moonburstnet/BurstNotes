/*    */ package com.shahramjaved.common;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class ExperienceUtil
/*    */ {
/*    */   public static int getTotalExperience(Player player)
/*    */   {
/* 10 */     int level = player.getLevel();
/* 11 */     if ((level >= 0) && (level <= 15)) {
/* 12 */       int experience = (int)Math.ceil(Math.pow(level, 2.0D) + 6 * level);
/* 13 */       int requiredExperience = 2 * level + 7;
/* 14 */       double currentExp = Double.parseDouble(Float.toString(player.getExp()));
/* 15 */       experience = (int)(experience + Math.ceil(currentExp * requiredExperience));
/* 16 */       return experience;
/* 17 */     }if ((level > 15) && (level <= 30)) {
/* 18 */       int experience = (int)Math.ceil(2.5D * Math.pow(level, 2.0D) - 40.5D * level + 360.0D);
/* 19 */       int requiredExperience = 5 * level - 38;
/* 20 */       double currentExp = Double.parseDouble(Float.toString(player.getExp()));
/* 21 */       experience = (int)(experience + Math.ceil(currentExp * requiredExperience));
/* 22 */       return experience;
/*    */     }
/* 24 */     int experience = (int)Math.ceil(4.5D * Math.pow(level, 2.0D) - 162.5D * level + 2220.0D);
/* 25 */     int requiredExperience = 9 * level - 158;
/* 26 */     double currentExp = Double.parseDouble(Float.toString(player.getExp()));
/* 27 */     experience = (int)(experience + Math.ceil(currentExp * requiredExperience));
/* 28 */     return experience;
/*    */   }
/*    */ 
/*    */   public static void setTotalExperience(Player player, int xp)
/*    */   {
/* 33 */     if ((xp >= 0) && (xp < 351)) {
/* 34 */       int a = 1;
/* 35 */       int b = 6;
/* 36 */       int c = -xp;
/* 37 */       int level = (int)(-b + Math.sqrt(Math.pow(b, 2.0D) - 4 * a * c)) / (2 * a);
/* 38 */       int xpForLevel = (int)(Math.pow(level, 2.0D) + 6 * level);
/* 39 */       int remainder = xp - xpForLevel;
/* 40 */       int experienceNeeded = 2 * level + 7;
/* 41 */       float experience = remainder / experienceNeeded;
/* 42 */       experience = round(experience, 2);
/*    */ 
/* 44 */       player.setLevel(level);
/* 45 */       player.setExp(experience);
/* 46 */     } else if ((xp >= 352) && (xp < 1507)) {
/* 47 */       double a = 2.5D;
/* 48 */       double b = -40.5D;
/* 49 */       int c = -xp + 360;
/* 50 */       double dLevel = (-b + Math.sqrt(Math.pow(b, 2.0D) - 4.0D * a * c)) / (2.0D * a);
/* 51 */       int level = (int)Math.floor(dLevel);
/* 52 */       int xpForLevel = (int)(2.5D * Math.pow(level, 2.0D) - 40.5D * level + 360.0D);
/* 53 */       int remainder = xp - xpForLevel;
/* 54 */       int experienceNeeded = 5 * level - 38;
/* 55 */       float experience = remainder / experienceNeeded;
/* 56 */       experience = round(experience, 2);
/* 57 */       player.setLevel(level);
/* 58 */       player.setExp(experience);
/*    */     } else {
/* 60 */       double a = 4.5D;
/* 61 */       double b = -162.5D;
/* 62 */       int c = -xp + 2220;
/* 63 */       double dLevel = (-b + Math.sqrt(Math.pow(b, 2.0D) - 4.0D * a * c)) / (2.0D * a);
/* 64 */       int level = (int)Math.floor(dLevel);
/* 65 */       int xpForLevel = (int)(4.5D * Math.pow(level, 2.0D) - 162.5D * level + 2220.0D);
/* 66 */       int remainder = xp - xpForLevel;
/* 67 */       int experienceNeeded = 9 * level - 158;
/* 68 */       float experience = remainder / experienceNeeded;
/* 69 */       experience = round(experience, 2);
/*    */ 
/* 71 */       player.setLevel(level);
/* 72 */       player.setExp(experience);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static float round(float d, int decimalPlace) {
/* 77 */     BigDecimal bd = new BigDecimal(Float.toString(d));
/* 78 */     bd = bd.setScale(decimalPlace, 5);
/* 79 */     return bd.floatValue();
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.common.ExperienceUtil
 * JD-Core Version:    0.6.2
 */
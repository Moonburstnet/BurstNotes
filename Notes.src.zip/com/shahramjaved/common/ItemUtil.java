/*    */ package com.shahramjaved.common;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.server.v1_8_R3.LocaleI18n;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.craftbukkit.v1_8_R3.enchantments.CraftEnchantment;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemFlag;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ 
/*    */ public class ItemUtil
/*    */ {
/*    */   public static void setItemInHandAir(Player p)
/*    */   {
/* 16 */     p.setItemInHand(null);
/*    */   }
/*    */ 
/*    */   public static boolean hasLore(ItemStack stack) {
/* 20 */     return (stack != null) && (stack.hasItemMeta()) && (stack.getItemMeta().hasLore());
/*    */   }
/*    */ 
/*    */   public static boolean hasDisplayName(ItemStack stack) {
/* 24 */     return (stack != null) && (stack.hasItemMeta()) && (stack.getItemMeta().hasDisplayName());
/*    */   }
/*    */ 
/*    */   public static boolean isValidItem(ItemStack stack) {
/* 28 */     return (stack != null) && (stack.getType() != Material.AIR);
/*    */   }
/*    */ 
/*    */   public static String getFriendlyEnchantmentName(org.bukkit.enchantments.Enchantment enchantment) {
/* 32 */     return LocaleI18n.get(CraftEnchantment.getRaw(enchantment).a());
/*    */   }
/*    */ 
/*    */   public static ItemStack emptyItem() {
/* 36 */     return new ItemStack(Material.AIR, 1);
/*    */   }
/*    */ 
/*    */   public static void removeLoreLine(ItemStack item, String line) {
/* 40 */     ItemMeta meta = item.getItemMeta();
/* 41 */     if (!meta.hasLore()) return;
/* 42 */     List lore = meta.getLore();
/* 43 */     lore.remove(line);
/* 44 */     meta.setLore(lore);
/* 45 */     item.setItemMeta(meta);
/*    */   }
/*    */ 
/*    */   public static void hideAttributes(ItemStack stack) {
/* 49 */     ItemMeta meta = stack.getItemMeta();
/* 50 */     meta.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ATTRIBUTES });
/* 51 */     stack.setItemMeta(meta);
/*    */   }
/*    */ 
/*    */   public static boolean isItemEmpty(ItemStack i) {
/* 55 */     return (i == null) || (i.getType() == Material.AIR);
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.common.ItemUtil
 * JD-Core Version:    0.6.2
 */
/*    */ package com.shahramjaved.nbt;
/*    */ 
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class NBTItem extends NBTCompound
/*    */ {
/*    */   private ItemStack bukkitItem;
/*    */ 
/*    */   public NBTItem(ItemStack item)
/*    */   {
/* 10 */     super(null, null);
/* 11 */     this.bukkitItem = item.clone();
/*    */   }
/*    */ 
/*    */   public static NBTContainer convertItemtoNBT(ItemStack item) {
/* 15 */     return NBTReflectionUtil.convertNMSItemtoNBTCompound(NBTReflectionUtil.getNMSItemStack(item));
/*    */   }
/*    */ 
/*    */   public static ItemStack convertNBTtoItem(NBTCompound comp) {
/* 19 */     return NBTReflectionUtil.getBukkitItemStack(NBTReflectionUtil.convertNBTCompoundtoNMSItem(comp));
/*    */   }
/*    */ 
/*    */   protected Object getCompound()
/*    */   {
/* 24 */     return NBTReflectionUtil.getItemRootNBTTagCompound(NBTReflectionUtil.getNMSItemStack(this.bukkitItem));
/*    */   }
/*    */ 
/*    */   protected void setCompound(Object compound)
/*    */   {
/* 29 */     this.bukkitItem = NBTReflectionUtil.getBukkitItemStack(NBTReflectionUtil.setNBTTag(compound, 
/* 30 */       NBTReflectionUtil.getNMSItemStack(this.bukkitItem)));
/*    */   }
/*    */ 
/*    */   public ItemStack getItem()
/*    */   {
/* 34 */     return this.bukkitItem;
/*    */   }
/*    */ 
/*    */   protected void setItem(ItemStack item) {
/* 38 */     this.bukkitItem = item;
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.nbt.NBTItem
 * JD-Core Version:    0.6.2
 */
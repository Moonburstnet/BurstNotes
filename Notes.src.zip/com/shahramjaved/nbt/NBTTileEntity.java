/*    */ package com.shahramjaved.nbt;
/*    */ 
/*    */ import org.bukkit.block.BlockState;
/*    */ 
/*    */ public class NBTTileEntity extends NBTCompound
/*    */ {
/*    */   private final BlockState tile;
/*    */ 
/*    */   public NBTTileEntity(BlockState tile)
/*    */   {
/* 10 */     super(null, null);
/* 11 */     this.tile = tile;
/*    */   }
/*    */ 
/*    */   protected Object getCompound()
/*    */   {
/* 16 */     return NBTReflectionUtil.getTileEntityNBTTagCompound(this.tile);
/*    */   }
/*    */ 
/*    */   protected void setCompound(Object compound)
/*    */   {
/* 21 */     NBTReflectionUtil.setTileEntityNBTTagCompound(this.tile, compound);
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.nbt.NBTTileEntity
 * JD-Core Version:    0.6.2
 */
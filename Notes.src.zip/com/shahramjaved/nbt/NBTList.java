/*     */ package com.shahramjaved.nbt;
/*     */ 
/*     */ import com.shahramjaved.nbt.utils.MethodNames;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ public class NBTList
/*     */ {
/*     */   private String listName;
/*     */   private NBTCompound parent;
/*     */   private NBTType type;
/*     */   private Object listObject;
/*     */ 
/*     */   protected NBTList(NBTCompound owner, String name, NBTType type, Object list)
/*     */   {
/*  15 */     this.parent = owner;
/*  16 */     this.listName = name;
/*  17 */     this.type = type;
/*  18 */     this.listObject = list;
/*  19 */     if ((type != NBTType.NBTTagString) && (type != NBTType.NBTTagCompound))
/*  20 */       System.err.println("List types != String/Compound are currently not implemented!");
/*     */   }
/*     */ 
/*     */   protected void save()
/*     */   {
/*  25 */     this.parent.set(this.listName, this.listObject);
/*     */   }
/*     */ 
/*     */   public NBTListCompound addCompound() {
/*  29 */     if (this.type != NBTType.NBTTagCompound) {
/*  30 */       new Throwable("Using Compound method on a non Compound list!").printStackTrace();
/*  31 */       return null;
/*     */     }
/*     */     try {
/*  34 */       Method method = this.listObject.getClass().getMethod("add", new Class[] { NBTReflectionUtil.getNBTBase() });
/*  35 */       Object compound = NBTReflectionUtil.getNBTTagCompound().newInstance();
/*  36 */       method.invoke(this.listObject, new Object[] { compound });
/*  37 */       return new NBTListCompound(this, compound);
/*     */     } catch (Exception ex) {
/*  39 */       ex.printStackTrace();
/*     */     }
/*  41 */     return null;
/*     */   }
/*     */ 
/*     */   public NBTListCompound getCompound(int id) {
/*  45 */     if (this.type != NBTType.NBTTagCompound) {
/*  46 */       new Throwable("Using Compound method on a non Compound list!").printStackTrace();
/*  47 */       return null;
/*     */     }
/*     */     try {
/*  50 */       Method method = this.listObject.getClass().getMethod("getEnchantedItem", new Class[] { Integer.TYPE });
/*  51 */       Object compound = method.invoke(this.listObject, new Object[] { Integer.valueOf(id) });
/*  52 */       return new NBTListCompound(this, compound);
/*     */     } catch (Exception ex) {
/*  54 */       ex.printStackTrace();
/*     */     }
/*  56 */     return null;
/*     */   }
/*     */ 
/*     */   public String getString(int i) {
/*  60 */     if (this.type != NBTType.NBTTagString) {
/*  61 */       new Throwable("Using String method on a non String list!").printStackTrace();
/*  62 */       return null;
/*     */     }
/*     */     try {
/*  65 */       Method method = this.listObject.getClass().getMethod("getString", new Class[] { Integer.TYPE });
/*  66 */       return (String)method.invoke(this.listObject, new Object[] { Integer.valueOf(i) });
/*     */     } catch (Exception ex) {
/*  68 */       ex.printStackTrace();
/*     */     }
/*  70 */     return null;
/*     */   }
/*     */ 
/*     */   public void addString(String s)
/*     */   {
/*  75 */     if (this.type != NBTType.NBTTagString) {
/*  76 */       new Throwable("Using String method on a non String list!").printStackTrace();
/*  77 */       return;
/*     */     }
/*     */     try {
/*  80 */       Method method = this.listObject.getClass().getMethod("add", new Class[] { NBTReflectionUtil.getNBTBase() });
/*  81 */       method.invoke(this.listObject, new Object[] { NBTReflectionUtil.getNBTTagString().getConstructor(new Class[] { String.class }).newInstance(new Object[] { s }) });
/*  82 */       save();
/*     */     } catch (Exception ex) {
/*  84 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setString(int i, String s)
/*     */   {
/*  90 */     if (this.type != NBTType.NBTTagString) {
/*  91 */       new Throwable("Using String method on a non String list!").printStackTrace();
/*  92 */       return;
/*     */     }
/*     */     try {
/*  95 */       Method method = this.listObject.getClass().getMethod("a", new Class[] { Integer.TYPE, NBTReflectionUtil.getNBTBase() });
/*  96 */       method.invoke(this.listObject, new Object[] { 
/*  97 */         Integer.valueOf(i), 
/*  98 */         NBTReflectionUtil.getNBTTagString().getConstructor(new Class[] { String.class }).newInstance(new Object[] { s }) });
/*  99 */       save();
/*     */     } catch (Exception ex) {
/* 101 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void remove(int i) {
/*     */     try {
/* 107 */       Method method = this.listObject.getClass().getMethod(MethodNames.getRemoveMethodName(), new Class[] { Integer.TYPE });
/* 108 */       method.invoke(this.listObject, new Object[] { Integer.valueOf(i) });
/* 109 */       save();
/*     */     } catch (Exception ex) {
/* 111 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public int size() {
/*     */     try {
/* 117 */       Method method = this.listObject.getClass().getMethod("size", new Class[0]);
/* 118 */       return ((Integer)method.invoke(this.listObject, new Object[0])).intValue();
/*     */     } catch (Exception ex) {
/* 120 */       ex.printStackTrace();
/*     */     }
/* 122 */     return -1;
/*     */   }
/*     */ 
/*     */   public NBTType getType() {
/* 126 */     return this.type;
/*     */   }
/*     */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.nbt.NBTList
 * JD-Core Version:    0.6.2
 */
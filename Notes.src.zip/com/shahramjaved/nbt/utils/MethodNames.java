/*    */ package com.shahramjaved.nbt.utils;
/*    */ 
/*    */ public class MethodNames
/*    */ {
/*  5 */   private static final MinecraftVersion MINECRAFT_VERSION = MinecraftVersion.getVersion();
/*    */ 
/*    */   public static String getTileDataMethodName() {
/*  8 */     if (MINECRAFT_VERSION == MinecraftVersion.MC1_8_R3) {
/*  9 */       return "b";
/*    */     }
/* 11 */     return "save";
/*    */   }
/*    */ 
/*    */   public static String getTypeMethodName() {
/* 15 */     if (MINECRAFT_VERSION == MinecraftVersion.MC1_8_R3) {
/* 16 */       return "b";
/*    */     }
/* 18 */     return "d";
/*    */   }
/*    */ 
/*    */   public static String getEntityNbtGetterMethodName() {
/* 22 */     return "b";
/*    */   }
/*    */ 
/*    */   public static String getEntityNbtSetterMethodName() {
/* 26 */     return "a";
/*    */   }
/*    */ 
/*    */   public static String getRemoveMethodName() {
/* 30 */     if (MINECRAFT_VERSION == MinecraftVersion.MC1_8_R3) {
/* 31 */       return "a";
/*    */     }
/* 33 */     return "remove";
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.nbt.utils.MethodNames
 * JD-Core Version:    0.6.2
 */
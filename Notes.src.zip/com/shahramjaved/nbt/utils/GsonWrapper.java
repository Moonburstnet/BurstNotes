/*    */ package com.shahramjaved.nbt.utils;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ 
/*    */ public class GsonWrapper
/*    */ {
/*  7 */   private static final Gson gson = new Gson();
/*    */ 
/*    */   public static String getString(Object obj) {
/* 10 */     return gson.toJson(obj);
/*    */   }
/*    */ 
/*    */   public static <T> T deserializeJson(String json, Class<T> type) {
/*    */     try {
/* 15 */       if (json == null) {
/* 16 */         return null;
/*    */       }
/*    */ 
/* 19 */       Object obj = gson.fromJson(json, type);
/* 20 */       return type.cast(obj);
/*    */     } catch (Exception ex) {
/* 22 */       ex.printStackTrace();
/* 23 */     }return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.nbt.utils.GsonWrapper
 * JD-Core Version:    0.6.2
 */
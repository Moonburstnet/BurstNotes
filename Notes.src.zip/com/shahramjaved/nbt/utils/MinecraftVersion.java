/*    */ package com.shahramjaved.nbt.utils;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public enum MinecraftVersion
/*    */ {
/*  6 */   Unknown(0), 
/*  7 */   MC1_7_R4(174), 
/*  8 */   MC1_8_R3(183), 
/*  9 */   MC1_9_R1(191), 
/* 10 */   MC1_9_R2(192), 
/* 11 */   MC1_10_R1(1101), 
/* 12 */   MC1_11_R1(1111), 
/* 13 */   MC1_12_R1(1121);
/*    */ 
/*    */   private static MinecraftVersion version;
/*    */   private static Boolean hasGsonSupport;
/*    */   private final int versionId;
/*    */ 
/* 21 */   private MinecraftVersion(int versionId) { this.versionId = versionId; }
/*    */ 
/*    */   public static MinecraftVersion getVersion()
/*    */   {
/* 25 */     if (version != null) {
/* 26 */       return version;
/*    */     }
/* 28 */     String ver = org.bukkit.Bukkit.getServer().getClass().getPackage().getName().replace(".", ",").split(",")[3];
/* 29 */     System.out.println("[NBTAPI] Found Spigot: " + ver + "! Trying to find NMS support");
/*    */     try {
/* 31 */       version = valueOf(ver.replace("v", "MC"));
/*    */     } catch (IllegalArgumentException ex) {
/* 33 */       version = Unknown;
/*    */     }
/* 35 */     if (version != Unknown)
/* 36 */       System.out.println("[NBTAPI] NMS support '" + version.name() + "' loaded!");
/*    */     else {
/* 38 */       System.out.println("[NBTAPI] Wasn't able to find NMS Support! Some functions will not work!");
/*    */     }
/* 40 */     return version;
/*    */   }
/*    */ 
/*    */   public static boolean hasGsonSupport() {
/* 44 */     if (hasGsonSupport != null)
/* 45 */       return hasGsonSupport.booleanValue();
/*    */     try
/*    */     {
/* 48 */       System.out.println("Found Gson: " + Class.forName("com.google.gson.Gson"));
/* 49 */       hasGsonSupport = Boolean.valueOf(true);
/*    */     } catch (Exception ex) {
/* 51 */       hasGsonSupport = Boolean.valueOf(false);
/*    */     }
/* 53 */     return hasGsonSupport.booleanValue();
/*    */   }
/*    */ 
/*    */   public int getVersionId() {
/* 57 */     return this.versionId;
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.nbt.utils.MinecraftVersion
 * JD-Core Version:    0.6.2
 */
/*     */ package com.shahramjaved.nbt;
/*     */ 
/*     */ import com.shahramjaved.nbt.utils.MinecraftVersion;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class NBTCompound
/*     */ {
/*     */   private String compundName;
/*     */   private NBTCompound parent;
/*     */ 
/*     */   protected NBTCompound(NBTCompound owner, String name)
/*     */   {
/*  13 */     this.compundName = name;
/*  14 */     this.parent = owner;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  18 */     return this.compundName;
/*     */   }
/*     */ 
/*     */   protected Object getCompound() {
/*  22 */     return this.parent.getCompound();
/*     */   }
/*     */ 
/*     */   protected void setCompound(Object compound) {
/*  26 */     this.parent.setCompound(compound);
/*     */   }
/*     */ 
/*     */   public NBTCompound getParent() {
/*  30 */     return this.parent;
/*     */   }
/*     */ 
/*     */   public void mergeCompound(NBTCompound comp) {
/*  34 */     NBTReflectionUtil.addOtherNBTCompound(this, comp);
/*     */   }
/*     */ 
/*     */   public void setString(String key, String value) {
/*  38 */     NBTReflectionUtil.setString(this, key, value);
/*     */   }
/*     */ 
/*     */   public String getString(String key) {
/*  42 */     return NBTReflectionUtil.getString(this, key);
/*     */   }
/*     */ 
/*     */   protected String getContent(String key) {
/*  46 */     return NBTReflectionUtil.getContent(this, key);
/*     */   }
/*     */ 
/*     */   public void setInteger(String key, Integer value) {
/*  50 */     NBTReflectionUtil.setInt(this, key, value);
/*     */   }
/*     */ 
/*     */   public Integer getInteger(String key) {
/*  54 */     return NBTReflectionUtil.getInt(this, key);
/*     */   }
/*     */ 
/*     */   public void setDouble(String key, Double value) {
/*  58 */     NBTReflectionUtil.setDouble(this, key, value);
/*     */   }
/*     */ 
/*     */   public Double getDouble(String key) {
/*  62 */     return NBTReflectionUtil.getDouble(this, key);
/*     */   }
/*     */ 
/*     */   public void setByte(String key, Byte value) {
/*  66 */     NBTReflectionUtil.setByte(this, key, value);
/*     */   }
/*     */ 
/*     */   public Byte getByte(String key) {
/*  70 */     return NBTReflectionUtil.getByte(this, key);
/*     */   }
/*     */ 
/*     */   public void setShort(String key, Short value) {
/*  74 */     NBTReflectionUtil.setShort(this, key, value);
/*     */   }
/*     */ 
/*     */   public Short getShort(String key) {
/*  78 */     return NBTReflectionUtil.getShort(this, key);
/*     */   }
/*     */ 
/*     */   public void setLong(String key, Long value) {
/*  82 */     NBTReflectionUtil.setLong(this, key, value);
/*     */   }
/*     */ 
/*     */   public Long getLong(String key) {
/*  86 */     return NBTReflectionUtil.getLong(this, key);
/*     */   }
/*     */ 
/*     */   public void setFloat(String key, Float value) {
/*  90 */     NBTReflectionUtil.setFloat(this, key, value);
/*     */   }
/*     */ 
/*     */   public Float getFloat(String key) {
/*  94 */     return NBTReflectionUtil.getFloat(this, key);
/*     */   }
/*     */ 
/*     */   public void setByteArray(String key, byte[] value) {
/*  98 */     NBTReflectionUtil.setByteArray(this, key, value);
/*     */   }
/*     */ 
/*     */   public byte[] getByteArray(String key) {
/* 102 */     return NBTReflectionUtil.getByteArray(this, key);
/*     */   }
/*     */ 
/*     */   public void setIntArray(String key, int[] value) {
/* 106 */     NBTReflectionUtil.setIntArray(this, key, value);
/*     */   }
/*     */ 
/*     */   public int[] getIntArray(String key) {
/* 110 */     return NBTReflectionUtil.getIntArray(this, key);
/*     */   }
/*     */ 
/*     */   public void setBoolean(String key, Boolean value) {
/* 114 */     NBTReflectionUtil.setBoolean(this, key, value);
/*     */   }
/*     */ 
/*     */   protected void set(String key, Object val) {
/* 118 */     NBTReflectionUtil.set(this, key, val);
/*     */   }
/*     */ 
/*     */   public Boolean getBoolean(String key) {
/* 122 */     return NBTReflectionUtil.getBoolean(this, key);
/*     */   }
/*     */ 
/*     */   public void setObject(String key, Object value) {
/* 126 */     NBTReflectionUtil.setObject(this, key, value);
/*     */   }
/*     */ 
/*     */   public <T> T getObject(String key, Class<T> type) {
/* 130 */     return NBTReflectionUtil.getObject(this, key, type);
/*     */   }
/*     */ 
/*     */   public Boolean hasKey(String key) {
/* 134 */     return NBTReflectionUtil.hasKey(this, key);
/*     */   }
/*     */ 
/*     */   public void removeKey(String key) {
/* 138 */     NBTReflectionUtil.remove(this, key);
/*     */   }
/*     */ 
/*     */   public Set<String> getKeys() {
/* 142 */     return NBTReflectionUtil.getKeys(this);
/*     */   }
/*     */ 
/*     */   public NBTCompound addCompound(String name) {
/* 146 */     NBTReflectionUtil.addNBTTagCompound(this, name);
/* 147 */     return getCompound(name);
/*     */   }
/*     */ 
/*     */   public NBTCompound getCompound(String name) {
/* 151 */     NBTCompound next = new NBTCompound(this, name);
/* 152 */     if (NBTReflectionUtil.valideCompound(next).booleanValue()) return next;
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */   public NBTList getList(String name, NBTType type) {
/* 157 */     return NBTReflectionUtil.getList(this, name, type);
/*     */   }
/*     */ 
/*     */   public NBTType getType(String name) {
/* 161 */     if (MinecraftVersion.getVersion() == MinecraftVersion.MC1_7_R4) return NBTType.NBTTagEnd;
/* 162 */     return NBTType.valueOf(NBTReflectionUtil.getType(this, name));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 167 */     StringBuilder result = new StringBuilder();
/* 168 */     for (String key : getKeys()) {
/* 169 */       result.append(toString(key));
/*     */     }
/* 171 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public String toString(String key) {
/* 175 */     StringBuilder result = new StringBuilder();
/* 176 */     NBTCompound compound = this;
/* 177 */     while (compound.getParent() != null) {
/* 178 */       result.append("   ");
/* 179 */       compound = compound.getParent();
/*     */     }
/* 181 */     if (getType(key) == NBTType.NBTTagCompound) {
/* 182 */       return getCompound(key).toString();
/*     */     }
/* 184 */     return new StringBuilder().append(result).append("-").append(key).append(": ").append(getContent(key)).append(System.lineSeparator()).toString();
/*     */   }
/*     */ 
/*     */   public String asNBTString()
/*     */   {
/* 189 */     return NBTReflectionUtil.gettoCompount(getCompound(), this).toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.nbt.NBTCompound
 * JD-Core Version:    0.6.2
 */
/*    */ package com.shahramjaved.nbt;
/*    */ 
/*    */ import org.bukkit.entity.Entity;
/*    */ 
/*    */ public class NBTEntity extends NBTCompound
/*    */ {
/*    */   private final Entity ent;
/*    */ 
/*    */   public NBTEntity(Entity entity)
/*    */   {
/* 10 */     super(null, null);
/* 11 */     this.ent = entity;
/*    */   }
/*    */ 
/*    */   protected Object getCompound()
/*    */   {
/* 16 */     return NBTReflectionUtil.getEntityNBTTagCompound(NBTReflectionUtil.getNMSEntity(this.ent));
/*    */   }
/*    */ 
/*    */   protected void setCompound(Object compound)
/*    */   {
/* 21 */     NBTReflectionUtil.setEntityNBTTag(compound, NBTReflectionUtil.getNMSEntity(this.ent));
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.nbt.NBTEntity
 * JD-Core Version:    0.6.2
 */
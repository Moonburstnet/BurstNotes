/*    */ package com.shahramjaved.nbt;
/*    */ 
/*    */ public class NBTContainer extends NBTCompound
/*    */ {
/*    */   private Object nbt;
/*    */ 
/*    */   public NBTContainer()
/*    */   {
/*  8 */     super(null, null);
/*  9 */     this.nbt = NBTReflectionUtil.getNewNBTTag();
/*    */   }
/*    */ 
/*    */   protected NBTContainer(Object nbt) {
/* 13 */     super(null, null);
/* 14 */     this.nbt = nbt;
/*    */   }
/*    */ 
/*    */   public NBTContainer(String nbtString) throws IllegalArgumentException {
/* 18 */     super(null, null);
/*    */     try {
/* 20 */       this.nbt = NBTReflectionUtil.parseNBT(nbtString);
/*    */     } catch (Exception ex) {
/* 22 */       ex.printStackTrace();
/* 23 */       throw new IllegalArgumentException("Malformed Json: " + ex.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   protected Object getCompound()
/*    */   {
/* 29 */     return this.nbt;
/*    */   }
/*    */ 
/*    */   protected void setCompound(Object tag)
/*    */   {
/* 34 */     this.nbt = tag;
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.nbt.NBTContainer
 * JD-Core Version:    0.6.2
 */
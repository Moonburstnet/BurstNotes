/*     */ package com.shahramjaved.nbt;
/*     */ 
/*     */ import com.shahramjaved.nbt.utils.GsonWrapper;
/*     */ import com.shahramjaved.nbt.utils.MethodNames;
/*     */ import com.shahramjaved.nbt.utils.MinecraftVersion;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.bukkit.block.BlockState;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class NBTReflectionUtil
/*     */ {
/*  27 */   private static final String version = org.bukkit.Bukkit.getServer()
/*  23 */     .getClass()
/*  24 */     .getPackage()
/*  25 */     .getName()
/*  26 */     .replace(".", ",")
/*  27 */     .split(",")[
/*  27 */     3];
/*     */ 
/*     */   private static Class getCraftItemStack()
/*     */   {
/*     */     try
/*     */     {
/*  33 */       return Class.forName("org.bukkit.craftbukkit." + version + ".inventory.CraftItemStack");
/*     */     }
/*     */     catch (Exception ex) {
/*  36 */       System.out.println("Error in ItemNBTAPI! (Outdated plugin?)");
/*  37 */       ex.printStackTrace();
/*  38 */     }return null;
/*     */   }
/*     */ 
/*     */   private static Class getCraftEntity()
/*     */   {
/*     */     try
/*     */     {
/*  45 */       return Class.forName("org.bukkit.craftbukkit." + version + ".entity.CraftEntity");
/*     */     }
/*     */     catch (Exception ex) {
/*  48 */       System.out.println("Error in ItemNBTAPI! (Outdated plugin?)");
/*  49 */       ex.printStackTrace();
/*  50 */     }return null;
/*     */   }
/*     */ 
/*     */   protected static Class getNBTBase()
/*     */   {
/*     */     try
/*     */     {
/*  57 */       return Class.forName("net.minecraft.server." + version + ".NBTBase");
/*     */     }
/*     */     catch (Exception ex) {
/*  60 */       System.out.println("Error in ItemNBTAPI! (Outdated plugin?)");
/*  61 */       ex.printStackTrace();
/*  62 */     }return null;
/*     */   }
/*     */ 
/*     */   protected static Class getNBTTagString()
/*     */   {
/*     */     try
/*     */     {
/*  69 */       return Class.forName("net.minecraft.server." + version + ".NBTTagString");
/*     */     }
/*     */     catch (Exception ex) {
/*  72 */       System.out.println("Error in ItemNBTAPI! (Outdated plugin?)");
/*  73 */       ex.printStackTrace();
/*  74 */     }return null;
/*     */   }
/*     */ 
/*     */   protected static Class getNMSItemStack()
/*     */   {
/*     */     try
/*     */     {
/*  81 */       return Class.forName("net.minecraft.server." + version + ".ItemStack");
/*     */     }
/*     */     catch (Exception ex) {
/*  84 */       System.out.println("Error in ItemNBTAPI! (Outdated plugin?)");
/*  85 */       ex.printStackTrace();
/*  86 */     }return null;
/*     */   }
/*     */ 
/*     */   protected static Class getNBTTagCompound()
/*     */   {
/*     */     try
/*     */     {
/*  93 */       return Class.forName("net.minecraft.server." + version + ".NBTTagCompound");
/*     */     }
/*     */     catch (Exception ex) {
/*  96 */       System.out.println("Error in ItemNBTAPI! (Outdated plugin?)");
/*  97 */       ex.printStackTrace();
/*  98 */     }return null;
/*     */   }
/*     */ 
/*     */   protected static Class getNBTCompressedStreamTools()
/*     */   {
/*     */     try
/*     */     {
/* 105 */       return Class.forName("net.minecraft.server." + version + ".NBTCompressedStreamTools");
/*     */     }
/*     */     catch (Exception ex) {
/* 108 */       System.out.println("Error in ItemNBTAPI! (Outdated plugin?)");
/* 109 */       ex.printStackTrace();
/* 110 */     }return null;
/*     */   }
/*     */ 
/*     */   protected static Class getMojangsonParser()
/*     */   {
/*     */     try
/*     */     {
/* 117 */       return Class.forName("net.minecraft.server." + version + ".MojangsonParser");
/*     */     }
/*     */     catch (Exception ex) {
/* 120 */       System.out.println("Error in ItemNBTAPI! (Outdated plugin?)");
/* 121 */       ex.printStackTrace();
/* 122 */     }return null;
/*     */   }
/*     */ 
/*     */   protected static Class getTileEntity()
/*     */   {
/*     */     try
/*     */     {
/* 129 */       return Class.forName("net.minecraft.server." + version + ".TileEntity");
/*     */     }
/*     */     catch (Exception ex) {
/* 132 */       System.out.println("Error in ItemNBTAPI! (Outdated plugin?)");
/* 133 */       ex.printStackTrace();
/* 134 */     }return null;
/*     */   }
/*     */ 
/*     */   protected static Class getCraftWorld()
/*     */   {
/*     */     try
/*     */     {
/* 141 */       return Class.forName("org.bukkit.craftbukkit." + version + ".CraftWorld");
/*     */     }
/*     */     catch (Exception ex) {
/* 144 */       System.out.println("Error in ItemNBTAPI! (Outdated plugin?)");
/* 145 */       ex.printStackTrace();
/* 146 */     }return null;
/*     */   }
/*     */ 
/*     */   public static Object getNewNBTTag()
/*     */   {
/* 151 */     String version = org.bukkit.Bukkit.getServer().getClass().getPackage().getName().replace(".", ",").split(",")[3];
/*     */     try
/*     */     {
/* 154 */       Class c = Class.forName("net.minecraft.server." + version + ".NBTTagCompound");
/* 155 */       return c.newInstance();
/*     */     } catch (Exception ex) {
/* 157 */       System.out.println("Error in ItemNBTAPI! (Outdated plugin?)");
/* 158 */       ex.printStackTrace();
/* 159 */     }return null;
/*     */   }
/*     */ 
/*     */   private static Object getNewBlockPosition(int x, int y, int z)
/*     */   {
/* 164 */     String version = org.bukkit.Bukkit.getServer().getClass().getPackage().getName().replace(".", ",").split(",")[3];
/*     */     try
/*     */     {
/* 167 */       Class clazz = Class.forName("net.minecraft.server." + version + ".BlockPosition");
/* 168 */       return clazz.getConstructor(new Class[] { Integer.TYPE, Integer.TYPE, Integer.TYPE }).newInstance(new Object[] { Integer.valueOf(x), Integer.valueOf(y), Integer.valueOf(z) });
/*     */     } catch (Exception ex) {
/* 170 */       System.out.println("Error in ItemNBTAPI! (Outdated plugin?)");
/* 171 */       ex.printStackTrace();
/* 172 */     }return null;
/*     */   }
/*     */ 
/*     */   public static Object setNBTTag(Object NBTTag, Object NMSItem)
/*     */   {
/*     */     try
/*     */     {
/* 179 */       Method method = NMSItem.getClass().getMethod("setTag", new Class[] { NBTTag.getClass() });
/* 180 */       method.invoke(NMSItem, new Object[] { NBTTag });
/* 181 */       return NMSItem;
/*     */     } catch (Exception ex) {
/* 183 */       ex.printStackTrace();
/*     */     }
/* 185 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object getNMSItemStack(ItemStack item)
/*     */   {
/* 191 */     Class clazz = getCraftItemStack();
/*     */     try
/*     */     {
/* 194 */       Method method = clazz.getMethod("asNMSCopy", new Class[] { ItemStack.class });
/* 195 */       return method.invoke(clazz, new Object[] { item });
/*     */     }
/*     */     catch (Exception e) {
/* 198 */       e.printStackTrace();
/*     */     }
/* 200 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object getNMSEntity(Entity entity)
/*     */   {
/* 206 */     Class clazz = getCraftEntity();
/*     */     try
/*     */     {
/* 209 */       Method method = clazz.getMethod("getHandle", new Class[0]);
/* 210 */       return method.invoke(getCraftEntity().cast(entity), new Object[0]);
/*     */     } catch (Exception e) {
/* 212 */       e.printStackTrace();
/*     */     }
/* 214 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object parseNBT(String json)
/*     */   {
/* 220 */     Class cis = getMojangsonParser();
/*     */     try
/*     */     {
/* 223 */       Method method = cis.getMethod("parse", new Class[] { String.class });
/* 224 */       return method.invoke(null, new Object[] { json });
/*     */     } catch (Exception e) {
/* 226 */       e.printStackTrace();
/*     */     }
/* 228 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object readNBTFile(FileInputStream stream)
/*     */   {
/* 234 */     Class clazz = getNBTCompressedStreamTools();
/*     */     try
/*     */     {
/* 237 */       Method method = clazz.getMethod("a", new Class[] { InputStream.class });
/* 238 */       return method.invoke(clazz, new Object[] { stream });
/*     */     } catch (Exception e) {
/* 240 */       e.printStackTrace();
/*     */     }
/* 242 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object saveNBTFile(Object nbt, FileOutputStream stream)
/*     */   {
/* 248 */     Class clazz = getNBTCompressedStreamTools();
/*     */     try
/*     */     {
/* 251 */       Method method = clazz.getMethod("a", new Class[] { getNBTTagCompound(), OutputStream.class });
/* 252 */       return method.invoke(clazz, new Object[] { nbt, stream });
/*     */     } catch (Exception e) {
/* 254 */       e.printStackTrace();
/*     */     }
/* 256 */     return null;
/*     */   }
/*     */ 
/*     */   public static ItemStack getBukkitItemStack(Object item)
/*     */   {
/* 262 */     Class clazz = getCraftItemStack();
/*     */     try
/*     */     {
/* 265 */       Method method = clazz.getMethod("asCraftMirror", new Class[] { item.getClass() });
/* 266 */       Object answer = method.invoke(clazz, new Object[] { item });
/* 267 */       return (ItemStack)answer;
/*     */     } catch (Exception e) {
/* 269 */       e.printStackTrace();
/*     */     }
/* 271 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object getItemRootNBTTagCompound(Object nmsitem)
/*     */   {
/* 277 */     Class clazz = nmsitem.getClass();
/*     */     try
/*     */     {
/* 280 */       Method method = clazz.getMethod("getTag", new Class[0]);
/* 281 */       return method.invoke(nmsitem, new Object[0]);
/*     */     }
/*     */     catch (Exception e) {
/* 284 */       e.printStackTrace();
/*     */     }
/* 286 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object convertNBTCompoundtoNMSItem(NBTCompound nbtcompound)
/*     */   {
/* 292 */     Class clazz = getNMSItemStack();
/*     */     try
/*     */     {
/* 295 */       return clazz.getConstructor(new Class[] { getNBTTagCompound() })
/* 295 */         .newInstance(new Object[] { 
/* 295 */         gettoCompount(nbtcompound
/* 295 */         .getCompound(), nbtcompound) });
/*     */     }
/*     */     catch (Exception e) {
/* 298 */       e.printStackTrace();
/*     */     }
/* 300 */     return null;
/*     */   }
/*     */ 
/*     */   public static NBTContainer convertNMSItemtoNBTCompound(Object nmsitem)
/*     */   {
/* 306 */     Class clazz = nmsitem.getClass();
/*     */     try
/*     */     {
/* 309 */       Method method = clazz.getMethod("save", new Class[] { getNBTTagCompound() });
/* 310 */       Object answer = method.invoke(nmsitem, new Object[] { getNewNBTTag() });
/* 311 */       return new NBTContainer(answer);
/*     */     } catch (Exception e) {
/* 313 */       e.printStackTrace();
/*     */     }
/* 315 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object getEntityNBTTagCompound(Object nmsitem)
/*     */   {
/* 321 */     Class c = nmsitem.getClass();
/*     */     try
/*     */     {
/* 324 */       Method method = c.getMethod(MethodNames.getEntityNbtGetterMethodName(), new Class[] { getNBTTagCompound() });
/* 325 */       Object nbt = getNBTTagCompound().newInstance();
/* 326 */       Object answer = method.invoke(nmsitem, new Object[] { nbt });
/* 327 */       if (answer == null);
/* 328 */       return nbt;
/*     */     }
/*     */     catch (Exception e) {
/* 331 */       e.printStackTrace();
/*     */     }
/* 333 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object setEntityNBTTag(Object NBTTag, Object NMSItem)
/*     */   {
/*     */     try {
/* 339 */       Method method = NMSItem.getClass().getMethod(MethodNames.getEntityNbtSetterMethodName(), new Class[] { getNBTTagCompound() });
/* 340 */       method.invoke(NMSItem, new Object[] { NBTTag });
/* 341 */       return NMSItem;
/*     */     } catch (Exception ex) {
/* 343 */       ex.printStackTrace();
/*     */     }
/* 345 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object getTileEntityNBTTagCompound(BlockState tile)
/*     */   {
/*     */     try {
/* 351 */       Object pos = getNewBlockPosition(tile.getX(), tile.getY(), tile.getZ());
/* 352 */       Object cworld = getCraftWorld().cast(tile.getWorld());
/* 353 */       Object nmsworld = cworld.getClass().getMethod("getHandle", new Class[0]).invoke(cworld, new Object[0]);
/* 354 */       Object o = nmsworld.getClass().getMethod("getTileEntity", new Class[] { pos.getClass() }).invoke(nmsworld, new Object[] { pos });
/* 355 */       Method method = getTileEntity().getMethod(MethodNames.getTileDataMethodName(), new Class[] { getNBTTagCompound() });
/* 356 */       Object tag = getNBTTagCompound().newInstance();
/* 357 */       Object answer = method.invoke(o, new Object[] { tag });
/* 358 */       if (answer == null);
/* 359 */       return tag;
/*     */     }
/*     */     catch (Exception e) {
/* 362 */       e.printStackTrace();
/*     */     }
/* 364 */     return null;
/*     */   }
/*     */ 
/*     */   public static void setTileEntityNBTTagCompound(BlockState tile, Object comp)
/*     */   {
/*     */     try {
/* 370 */       Object pos = getNewBlockPosition(tile.getX(), tile.getY(), tile.getZ());
/* 371 */       Object cworld = getCraftWorld().cast(tile.getWorld());
/* 372 */       Object nmsworld = cworld.getClass().getMethod("getHandle", new Class[0]).invoke(cworld, new Object[0]);
/* 373 */       Object o = nmsworld.getClass().getMethod("getTileEntity", new Class[] { pos.getClass() }).invoke(nmsworld, new Object[] { pos });
/* 374 */       Method method = getTileEntity().getMethod("a", new Class[] { getNBTTagCompound() });
/* 375 */       method.invoke(o, new Object[] { comp });
/*     */     } catch (Exception e) {
/* 377 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object getSubNBTTagCompound(Object compound, String name)
/*     */   {
/* 385 */     Class c = compound.getClass();
/*     */     try
/*     */     {
/* 388 */       Method method = c.getMethod("getCompound", new Class[] { String.class });
/* 389 */       return method.invoke(compound, new Object[] { name });
/*     */     }
/*     */     catch (Exception e) {
/* 392 */       e.printStackTrace();
/*     */     }
/* 394 */     return null;
/*     */   }
/*     */ 
/*     */   public static void addNBTTagCompound(NBTCompound comp, String name) {
/* 398 */     if (name == null) {
/* 399 */       remove(comp, name);
/* 400 */       return;
/*     */     }
/* 402 */     Object nbttag = comp.getCompound();
/* 403 */     if (nbttag == null) {
/* 404 */       nbttag = getNewNBTTag();
/*     */     }
/* 406 */     if (!valideCompound(comp).booleanValue()) return;
/* 407 */     Object workingtag = gettoCompount(nbttag, comp);
/*     */     try
/*     */     {
/* 410 */       Method method = workingtag.getClass().getMethod("set", new Class[] { String.class, getNBTBase() });
/* 411 */       method.invoke(workingtag, new Object[] { name, getNBTTagCompound().newInstance() });
/* 412 */       comp.setCompound(nbttag);
/* 413 */       return;
/*     */     } catch (Exception ex) {
/* 415 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Boolean valideCompound(NBTCompound comp)
/*     */   {
/* 421 */     Object root = comp.getCompound();
/* 422 */     if (root == null) {
/* 423 */       root = getNewNBTTag();
/*     */     }
/* 425 */     return Boolean.valueOf(gettoCompount(root, comp) != null);
/*     */   }
/*     */ 
/*     */   public static Object gettoCompount(Object nbttag, NBTCompound comp) {
/* 429 */     Stack structure = new Stack();
/* 430 */     while (comp.getParent() != null) {
/* 431 */       structure.add(comp.getName());
/* 432 */       comp = comp.getParent();
/*     */     }
/* 434 */     while (!structure.isEmpty()) {
/* 435 */       nbttag = getSubNBTTagCompound(nbttag, (String)structure.pop());
/* 436 */       if (nbttag == null) {
/* 437 */         return null;
/*     */       }
/*     */     }
/* 440 */     return nbttag;
/*     */   }
/*     */ 
/*     */   public static void addOtherNBTCompound(NBTCompound comp, NBTCompound nbtcompound) {
/* 444 */     Object rootnbttag = comp.getCompound();
/* 445 */     if (rootnbttag == null) {
/* 446 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 448 */     if (!valideCompound(comp).booleanValue()) return;
/* 449 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 452 */       Method method = workingtag.getClass().getMethod("a", new Class[] { getNBTTagCompound() });
/* 453 */       method.invoke(workingtag, new Object[] { nbtcompound.getCompound() });
/* 454 */       comp.setCompound(rootnbttag);
/*     */     } catch (Exception ex) {
/* 456 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void setString(NBTCompound comp, String key, String text) {
/* 461 */     if (text == null) {
/* 462 */       remove(comp, key);
/* 463 */       return;
/*     */     }
/* 465 */     Object rootnbttag = comp.getCompound();
/* 466 */     if (rootnbttag == null) {
/* 467 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 469 */     if (!valideCompound(comp).booleanValue()) return;
/* 470 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 473 */       Method method = workingtag.getClass().getMethod("setString", new Class[] { String.class, String.class });
/* 474 */       method.invoke(workingtag, new Object[] { key, text });
/* 475 */       comp.setCompound(rootnbttag);
/*     */     } catch (Exception ex) {
/* 477 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getString(NBTCompound comp, String key) {
/* 482 */     Object rootnbttag = comp.getCompound();
/* 483 */     if (rootnbttag == null) {
/* 484 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 486 */     if (!valideCompound(comp).booleanValue()) return null;
/* 487 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 490 */       Method method = workingtag.getClass().getMethod("getString", new Class[] { String.class });
/* 491 */       return (String)method.invoke(workingtag, new Object[] { key });
/*     */     } catch (Exception ex) {
/* 493 */       ex.printStackTrace();
/*     */     }
/* 495 */     return null;
/*     */   }
/*     */ 
/*     */   public static String getContent(NBTCompound comp, String key) {
/* 499 */     Object rootnbttag = comp.getCompound();
/* 500 */     if (rootnbttag == null) {
/* 501 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 503 */     if (!valideCompound(comp).booleanValue()) return null;
/* 504 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 507 */       Method method = workingtag.getClass().getMethod("getEnchantedItem", new Class[] { String.class });
/* 508 */       return method.invoke(workingtag, new Object[] { key }).toString();
/*     */     } catch (Exception ex) {
/* 510 */       ex.printStackTrace();
/*     */     }
/* 512 */     return null;
/*     */   }
/*     */ 
/*     */   public static void setInt(NBTCompound comp, String key, Integer i) {
/* 516 */     if (i == null) {
/* 517 */       remove(comp, key);
/* 518 */       return;
/*     */     }
/* 520 */     Object rootnbttag = comp.getCompound();
/* 521 */     if (rootnbttag == null) {
/* 522 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 524 */     if (!valideCompound(comp).booleanValue()) return;
/* 525 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 528 */       Method method = workingtag.getClass().getMethod("setInt", new Class[] { String.class, Integer.TYPE });
/* 529 */       method.invoke(workingtag, new Object[] { key, i });
/* 530 */       comp.setCompound(rootnbttag);
/*     */     } catch (Exception ex) {
/* 532 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Integer getInt(NBTCompound comp, String key) {
/* 537 */     Object rootnbttag = comp.getCompound();
/* 538 */     if (rootnbttag == null) {
/* 539 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 541 */     if (!valideCompound(comp).booleanValue()) return null;
/* 542 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 545 */       Method method = workingtag.getClass().getMethod("getInt", new Class[] { String.class });
/* 546 */       return (Integer)method.invoke(workingtag, new Object[] { key });
/*     */     } catch (Exception ex) {
/* 548 */       ex.printStackTrace();
/*     */     }
/* 550 */     return null;
/*     */   }
/*     */ 
/*     */   public static void setByteArray(NBTCompound comp, String key, byte[] b) {
/* 554 */     if (b == null) {
/* 555 */       remove(comp, key);
/* 556 */       return;
/*     */     }
/* 558 */     Object rootnbttag = comp.getCompound();
/* 559 */     if (rootnbttag == null) {
/* 560 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 562 */     if (!valideCompound(comp).booleanValue()) return;
/* 563 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 566 */       Method method = workingtag.getClass().getMethod("setByteArray", new Class[] { String.class, [B.class });
/* 567 */       method.invoke(workingtag, new Object[] { key, b });
/* 568 */       comp.setCompound(rootnbttag);
/*     */     } catch (Exception ex) {
/* 570 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static byte[] getByteArray(NBTCompound comp, String key)
/*     */   {
/* 576 */     Object rootnbttag = comp.getCompound();
/* 577 */     if (rootnbttag == null) {
/* 578 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 580 */     if (!valideCompound(comp).booleanValue()) return null;
/* 581 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 584 */       Method method = workingtag.getClass().getMethod("getByteArray", new Class[] { String.class });
/* 585 */       return (byte[])method.invoke(workingtag, new Object[] { key });
/*     */     } catch (Exception ex) {
/* 587 */       ex.printStackTrace();
/*     */     }
/* 589 */     return null;
/*     */   }
/*     */ 
/*     */   public static void setIntArray(NBTCompound comp, String key, int[] i) {
/* 593 */     if (i == null) {
/* 594 */       remove(comp, key);
/* 595 */       return;
/*     */     }
/* 597 */     Object rootnbttag = comp.getCompound();
/* 598 */     if (rootnbttag == null) {
/* 599 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 601 */     if (!valideCompound(comp).booleanValue()) return;
/* 602 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 605 */       Method method = workingtag.getClass().getMethod("setIntArray", new Class[] { String.class, [I.class });
/* 606 */       method.invoke(workingtag, new Object[] { key, i });
/* 607 */       comp.setCompound(rootnbttag);
/*     */     } catch (Exception ex) {
/* 609 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int[] getIntArray(NBTCompound comp, String key) {
/* 614 */     Object rootnbttag = comp.getCompound();
/* 615 */     if (rootnbttag == null) {
/* 616 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 618 */     if (!valideCompound(comp).booleanValue()) return null;
/* 619 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 622 */       Method method = workingtag.getClass().getMethod("getIntArray", new Class[] { String.class });
/* 623 */       return (int[])method.invoke(workingtag, new Object[] { key });
/*     */     } catch (Exception ex) {
/* 625 */       ex.printStackTrace();
/*     */     }
/* 627 */     return null;
/*     */   }
/*     */ 
/*     */   public static void setFloat(NBTCompound comp, String key, Float f) {
/* 631 */     if (f == null) {
/* 632 */       remove(comp, key);
/* 633 */       return;
/*     */     }
/* 635 */     Object rootnbttag = comp.getCompound();
/* 636 */     if (rootnbttag == null) {
/* 637 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 639 */     if (!valideCompound(comp).booleanValue()) return;
/* 640 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 643 */       Method method = workingtag.getClass().getMethod("setFloat", new Class[] { String.class, Float.TYPE });
/* 644 */       method.invoke(workingtag, new Object[] { key, Float.valueOf(f.floatValue()) });
/* 645 */       comp.setCompound(rootnbttag);
/*     */     } catch (Exception ex) {
/* 647 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Float getFloat(NBTCompound comp, String key) {
/* 652 */     Object rootnbttag = comp.getCompound();
/* 653 */     if (rootnbttag == null) {
/* 654 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 656 */     if (!valideCompound(comp).booleanValue()) return null;
/* 657 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 660 */       Method method = workingtag.getClass().getMethod("getFloat", new Class[] { String.class });
/* 661 */       return (Float)method.invoke(workingtag, new Object[] { key });
/*     */     } catch (Exception ex) {
/* 663 */       ex.printStackTrace();
/*     */     }
/* 665 */     return null;
/*     */   }
/*     */ 
/*     */   public static void setLong(NBTCompound comp, String key, Long f) {
/* 669 */     if (f == null) {
/* 670 */       remove(comp, key);
/* 671 */       return;
/*     */     }
/* 673 */     Object rootnbttag = comp.getCompound();
/* 674 */     if (rootnbttag == null) {
/* 675 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 677 */     if (!valideCompound(comp).booleanValue()) return;
/* 678 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 681 */       Method method = workingtag.getClass().getMethod("setLong", new Class[] { String.class, Long.TYPE });
/* 682 */       method.invoke(workingtag, new Object[] { key, Long.valueOf(f.longValue()) });
/* 683 */       comp.setCompound(rootnbttag);
/*     */     } catch (Exception ex) {
/* 685 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Long getLong(NBTCompound comp, String key) {
/* 690 */     Object rootnbttag = comp.getCompound();
/* 691 */     if (rootnbttag == null) {
/* 692 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 694 */     if (!valideCompound(comp).booleanValue()) return null;
/* 695 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 698 */       Method method = workingtag.getClass().getMethod("getLong", new Class[] { String.class });
/* 699 */       return (Long)method.invoke(workingtag, new Object[] { key });
/*     */     } catch (Exception ex) {
/* 701 */       ex.printStackTrace();
/*     */     }
/* 703 */     return null;
/*     */   }
/*     */ 
/*     */   public static void setShort(NBTCompound comp, String key, Short f) {
/* 707 */     if (f == null) {
/* 708 */       remove(comp, key);
/* 709 */       return;
/*     */     }
/* 711 */     Object rootnbttag = comp.getCompound();
/* 712 */     if (rootnbttag == null) {
/* 713 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 715 */     if (!valideCompound(comp).booleanValue()) return;
/* 716 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 719 */       Method method = workingtag.getClass().getMethod("setShort", new Class[] { String.class, Short.TYPE });
/* 720 */       method.invoke(workingtag, new Object[] { key, Short.valueOf(f.shortValue()) });
/* 721 */       comp.setCompound(rootnbttag);
/*     */     } catch (Exception ex) {
/* 723 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Short getShort(NBTCompound comp, String key) {
/* 728 */     Object rootnbttag = comp.getCompound();
/* 729 */     if (rootnbttag == null) {
/* 730 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 732 */     if (!valideCompound(comp).booleanValue()) return null;
/* 733 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 736 */       Method method = workingtag.getClass().getMethod("getShort", new Class[] { String.class });
/* 737 */       return (Short)method.invoke(workingtag, new Object[] { key });
/*     */     } catch (Exception ex) {
/* 739 */       ex.printStackTrace();
/*     */     }
/* 741 */     return null;
/*     */   }
/*     */ 
/*     */   public static void setByte(NBTCompound comp, String key, Byte f) {
/* 745 */     if (f == null) {
/* 746 */       remove(comp, key);
/* 747 */       return;
/*     */     }
/* 749 */     Object rootnbttag = comp.getCompound();
/* 750 */     if (rootnbttag == null) {
/* 751 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 753 */     if (!valideCompound(comp).booleanValue()) return;
/* 754 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 757 */       Method method = workingtag.getClass().getMethod("setByte", new Class[] { String.class, Byte.TYPE });
/* 758 */       method.invoke(workingtag, new Object[] { key, Byte.valueOf(f.byteValue()) });
/* 759 */       comp.setCompound(rootnbttag);
/*     */     } catch (Exception ex) {
/* 761 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Byte getByte(NBTCompound comp, String key) {
/* 766 */     Object rootnbttag = comp.getCompound();
/* 767 */     if (rootnbttag == null) {
/* 768 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 770 */     if (!valideCompound(comp).booleanValue()) return null;
/* 771 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 774 */       Method method = workingtag.getClass().getMethod("getByte", new Class[] { String.class });
/* 775 */       return (Byte)method.invoke(workingtag, new Object[] { key });
/*     */     } catch (Exception ex) {
/* 777 */       ex.printStackTrace();
/*     */     }
/* 779 */     return null;
/*     */   }
/*     */ 
/*     */   public static void setDouble(NBTCompound comp, String key, Double d) {
/* 783 */     if (d == null) {
/* 784 */       remove(comp, key);
/* 785 */       return;
/*     */     }
/* 787 */     Object rootnbttag = comp.getCompound();
/* 788 */     if (rootnbttag == null) {
/* 789 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 791 */     if (!valideCompound(comp).booleanValue()) return;
/* 792 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 795 */       Method method = workingtag.getClass().getMethod("setDouble", new Class[] { String.class, Double.TYPE });
/* 796 */       method.invoke(workingtag, new Object[] { key, d });
/* 797 */       comp.setCompound(rootnbttag);
/*     */     } catch (Exception ex) {
/* 799 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Double getDouble(NBTCompound comp, String key) {
/* 804 */     Object rootnbttag = comp.getCompound();
/* 805 */     if (rootnbttag == null) {
/* 806 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 808 */     if (!valideCompound(comp).booleanValue()) return null;
/* 809 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 812 */       Method method = workingtag.getClass().getMethod("getDouble", new Class[] { String.class });
/* 813 */       return (Double)method.invoke(workingtag, new Object[] { key });
/*     */     } catch (Exception ex) {
/* 815 */       ex.printStackTrace();
/*     */     }
/* 817 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte getType(NBTCompound comp, String key) {
/* 821 */     Object rootnbttag = comp.getCompound();
/* 822 */     if (rootnbttag == null) {
/* 823 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 825 */     if (!valideCompound(comp).booleanValue()) return 0;
/* 826 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 829 */       Method method = workingtag.getClass().getMethod(MethodNames.getTypeMethodName(), new Class[] { String.class });
/* 830 */       return ((Byte)method.invoke(workingtag, new Object[] { key })).byteValue();
/*     */     } catch (Exception ex) {
/* 832 */       ex.printStackTrace();
/*     */     }
/* 834 */     return 0;
/*     */   }
/*     */ 
/*     */   public static void setBoolean(NBTCompound comp, String key, Boolean d) {
/* 838 */     if (d == null) {
/* 839 */       remove(comp, key);
/* 840 */       return;
/*     */     }
/* 842 */     Object rootnbttag = comp.getCompound();
/* 843 */     if (rootnbttag == null) {
/* 844 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 846 */     if (!valideCompound(comp).booleanValue()) return;
/* 847 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 850 */       Method method = workingtag.getClass().getMethod("setBoolean", new Class[] { String.class, Boolean.TYPE });
/* 851 */       method.invoke(workingtag, new Object[] { key, d });
/* 852 */       comp.setCompound(rootnbttag);
/*     */     } catch (Exception ex) {
/* 854 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Boolean getBoolean(NBTCompound comp, String key) {
/* 859 */     Object rootnbttag = comp.getCompound();
/* 860 */     if (rootnbttag == null) {
/* 861 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 863 */     if (!valideCompound(comp).booleanValue()) return null;
/* 864 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 867 */       Method method = workingtag.getClass().getMethod("getBoolean", new Class[] { String.class });
/* 868 */       return (Boolean)method.invoke(workingtag, new Object[] { key });
/*     */     } catch (Exception ex) {
/* 870 */       ex.printStackTrace();
/*     */     }
/* 872 */     return null;
/*     */   }
/*     */ 
/*     */   public static void set(NBTCompound comp, String key, Object val) {
/* 876 */     if (val == null) {
/* 877 */       remove(comp, key);
/* 878 */       return;
/*     */     }
/* 880 */     Object rootnbttag = comp.getCompound();
/* 881 */     if (rootnbttag == null) {
/* 882 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 884 */     if (!valideCompound(comp).booleanValue()) {
/* 885 */       new Throwable("InvalideCompound").printStackTrace();
/* 886 */       return;
/*     */     }
/* 888 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 891 */       Method method = workingtag.getClass().getMethod("set", new Class[] { String.class, getNBTBase() });
/* 892 */       method.invoke(workingtag, new Object[] { key, val });
/* 893 */       comp.setCompound(rootnbttag);
/*     */     } catch (Exception ex) {
/* 895 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static NBTList getList(NBTCompound comp, String key, NBTType type) {
/* 900 */     Object rootnbttag = comp.getCompound();
/* 901 */     if (rootnbttag == null) {
/* 902 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 904 */     if (!valideCompound(comp).booleanValue()) return null;
/* 905 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 908 */       Method method = workingtag.getClass().getMethod("getList", new Class[] { String.class, Integer.TYPE });
/* 909 */       return new NBTList(comp, key, type, method.invoke(workingtag, new Object[] { key, Integer.valueOf(type.getId()) }));
/*     */     } catch (Exception ex) {
/* 911 */       ex.printStackTrace();
/*     */     }
/* 913 */     return null;
/*     */   }
/*     */ 
/*     */   public static void setObject(NBTCompound comp, String key, Object value) {
/* 917 */     if (!MinecraftVersion.hasGsonSupport()) return; try
/*     */     {
/* 919 */       String json = GsonWrapper.getString(value);
/* 920 */       setString(comp, key, json);
/*     */     } catch (Exception ex) {
/* 922 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <T> T getObject(NBTCompound comp, String key, Class<T> type) {
/* 927 */     if (!MinecraftVersion.hasGsonSupport()) return null;
/* 928 */     String json = getString(comp, key);
/* 929 */     if (json == null) {
/* 930 */       return null;
/*     */     }
/* 932 */     return GsonWrapper.deserializeJson(json, type);
/*     */   }
/*     */ 
/*     */   public static void remove(NBTCompound comp, String key) {
/* 936 */     Object rootnbttag = comp.getCompound();
/* 937 */     if (rootnbttag == null) {
/* 938 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 940 */     if (!valideCompound(comp).booleanValue()) return;
/* 941 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 944 */       Method method = workingtag.getClass().getMethod("remove", new Class[] { String.class });
/* 945 */       method.invoke(workingtag, new Object[] { key });
/* 946 */       comp.setCompound(rootnbttag);
/*     */     } catch (Exception ex) {
/* 948 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Boolean hasKey(NBTCompound comp, String key) {
/* 953 */     Object rootnbttag = comp.getCompound();
/* 954 */     if (rootnbttag == null) {
/* 955 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 957 */     if (!valideCompound(comp).booleanValue()) return null;
/* 958 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 961 */       Method method = workingtag.getClass().getMethod("hasKey", new Class[] { String.class });
/* 962 */       return (Boolean)method.invoke(workingtag, new Object[] { key });
/*     */     } catch (Exception ex) {
/* 964 */       ex.printStackTrace();
/*     */     }
/* 966 */     return null;
/*     */   }
/*     */ 
/*     */   public static Set<String> getKeys(NBTCompound comp)
/*     */   {
/* 971 */     Object rootnbttag = comp.getCompound();
/* 972 */     if (rootnbttag == null) {
/* 973 */       rootnbttag = getNewNBTTag();
/*     */     }
/* 975 */     if (!valideCompound(comp).booleanValue()) return null;
/* 976 */     Object workingtag = gettoCompount(rootnbttag, comp);
/*     */     try
/*     */     {
/* 979 */       Method method = workingtag.getClass().getMethod("c", new Class[0]);
/* 980 */       return (Set)method.invoke(workingtag, new Object[0]);
/*     */     } catch (Exception ex) {
/* 982 */       ex.printStackTrace();
/*     */     }
/* 984 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.nbt.NBTReflectionUtil
 * JD-Core Version:    0.6.2
 */
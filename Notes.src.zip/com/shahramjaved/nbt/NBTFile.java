/*    */ package com.shahramjaved.nbt;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class NBTFile extends NBTCompound
/*    */ {
/*    */   private final File file;
/*    */   private Object nbt;
/*    */ 
/*    */   public NBTFile(File file)
/*    */     throws IOException
/*    */   {
/* 14 */     super(null, null);
/* 15 */     this.file = file;
/* 16 */     if (file.exists()) {
/* 17 */       FileInputStream inputsteam = new FileInputStream(file);
/* 18 */       this.nbt = NBTReflectionUtil.readNBTFile(inputsteam);
/*    */     } else {
/* 20 */       this.nbt = NBTReflectionUtil.getNewNBTTag();
/* 21 */       save();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void save() throws IOException {
/* 26 */     if (!this.file.exists()) {
/* 27 */       this.file.getParentFile().mkdirs();
/* 28 */       this.file.createNewFile();
/*    */     }
/* 30 */     FileOutputStream outStream = new FileOutputStream(this.file);
/* 31 */     NBTReflectionUtil.saveNBTFile(this.nbt, outStream);
/*    */   }
/*    */ 
/*    */   public File getFile() {
/* 35 */     return this.file;
/*    */   }
/*    */ 
/*    */   protected Object getCompound()
/*    */   {
/* 40 */     return this.nbt;
/*    */   }
/*    */ 
/*    */   protected void setCompound(Object compound)
/*    */   {
/* 45 */     this.nbt = compound;
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.nbt.NBTFile
 * JD-Core Version:    0.6.2
 */
/*    */ package com.shahramjaved.nbt;
/*    */ 
/*    */ public enum NBTType
/*    */ {
/*  4 */   NBTTagEnd(0), 
/*  5 */   NBTTagByte(1), 
/*  6 */   NBTTagShort(2), 
/*  7 */   NBTTagInt(3), 
/*  8 */   NBTTagLong(4), 
/*  9 */   NBTTagFloat(5), 
/* 10 */   NBTTagDouble(6), 
/* 11 */   NBTTagByteArray(7), 
/* 12 */   NBTTagIntArray(11), 
/* 13 */   NBTTagString(8), 
/* 14 */   NBTTagList(9), 
/* 15 */   NBTTagCompound(10);
/*    */ 
/*    */   private final int id;
/*    */ 
/*    */   private NBTType(int i) {
/* 20 */     this.id = i;
/*    */   }
/*    */ 
/*    */   public static NBTType valueOf(int id) {
/* 24 */     for (NBTType t : values())
/* 25 */       if (t.getId() == id)
/* 26 */         return t;
/* 27 */     return NBTTagEnd;
/*    */   }
/*    */ 
/*    */   public int getId() {
/* 31 */     return this.id;
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.nbt.NBTType
 * JD-Core Version:    0.6.2
 */
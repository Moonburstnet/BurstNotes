/*    */ package com.shahramjaved.notes.banknotes;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.shahramjaved.common.ItemUtil;
/*    */ import com.shahramjaved.nbt.NBTItem;
/*    */ import java.text.NumberFormat;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemFlag;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ 
/*    */ public final class BankNoteItem
/*    */ {
/*    */   public static final String MONEY_STORED_TAG = "MoneyStored";
/*    */ 
/*    */   public static ItemStack createBankNote(Player player, int money)
/*    */   {
/* 24 */     ItemStack bankNote = new ItemStack(Material.PAPER, 1);
/* 25 */     ItemMeta meta = bankNote.getItemMeta();
/* 26 */     meta.setDisplayName(ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "BANKNOTE");
/* 27 */     List lore = Lists.newArrayList();
/* 28 */     lore.add(ChatColor.LIGHT_PURPLE + "Signed: " + ChatColor.WHITE + player.getName());
/* 29 */     lore.add(ChatColor.LIGHT_PURPLE + "Amount: " + ChatColor.WHITE + "$" + NumberFormat.getInstance(Locale.US).format(money));
/* 30 */     lore.add(ChatColor.DARK_GRAY + "[" + ChatColor.GRAY + "Right-Click" + ChatColor.DARK_GRAY + "]");
/* 31 */     meta.setLore(lore);
/* 32 */     meta.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ATTRIBUTES });
/* 33 */     bankNote.setItemMeta(meta);
/*    */ 
/* 35 */     NBTItem nbt = new NBTItem(bankNote);
/* 36 */     nbt.setInteger("MoneyStored", Integer.valueOf(money));
/*    */ 
/* 38 */     return nbt.getItem();
/*    */   }
/*    */ 
/*    */   public static boolean isBankNote(ItemStack item) {
/* 42 */     return (!ItemUtil.isItemEmpty(item)) && (new NBTItem(item).hasKey("MoneyStored").booleanValue());
/*    */   }
/*    */ 
/*    */   public static int getMoneyStored(ItemStack bottle) {
/* 46 */     return new NBTItem(bottle).getInteger("MoneyStored").intValue();
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.notes.banknotes.BankNoteItem
 * JD-Core Version:    0.6.2
 */
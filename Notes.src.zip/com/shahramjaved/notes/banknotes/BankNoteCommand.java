/*    */ package com.shahramjaved.notes.banknotes;
/*    */ 
/*    */ import com.shahramjaved.common.ChatUtil;
/*    */ import com.shahramjaved.common.InventoryUtil;
/*    */ import com.shahramjaved.notes.Messages;
/*    */ import com.shahramjaved.notes.NotesPlugin;
/*    */ import net.milkbowl.vault.economy.Economy;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class BankNoteCommand
/*    */   implements CommandExecutor
/*    */ {
/* 15 */   private static Economy economy = NotesPlugin.instance.getEconomy();
/*    */ 
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
/*    */   {
/* 19 */     if (!(sender instanceof Player)) {
/* 20 */       sender.sendMessage(Messages.get("must-be-player"));
/* 21 */       return false;
/*    */     }
/*    */ 
/* 24 */     Player player = (Player)sender;
/*    */ 
/* 26 */     if (cmd.getName().equalsIgnoreCase("banknote")) {
/* 27 */       if (args.length == 1) {
/*    */         try {
/* 29 */           int money = Integer.parseInt(args[0]);
/*    */ 
/* 31 */           if (economy.getBalance(player) >= money) {
/* 32 */             economy.withdrawPlayer(player, money);
/* 33 */             InventoryUtil.addItemsOrDrop(player, new ItemStack[] { BankNoteItem.createBankNote(player, money) });
/*    */ 
/* 35 */             String successMsg = Messages.get("banknote-success");
/* 36 */             successMsg = successMsg.replace("{amount}", ChatUtil.toCommaString(money));
/* 37 */             player.sendMessage(successMsg);
/*    */           } else {
/* 39 */             player.sendMessage(Messages.get("banknote-not-enough-money"));
/*    */           }
/*    */         } catch (NumberFormatException e) {
/* 42 */           sender.sendMessage(Messages.get("not-valid-integer"));
/* 43 */           return false;
/*    */         }
/*    */       } else {
/* 46 */         player.sendMessage(Messages.get("bad-number-arguments"));
/* 47 */         player.sendMessage(Messages.get("banknote-usage"));
/*    */       }
/*    */     }
/*    */ 
/* 51 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.notes.banknotes.BankNoteCommand
 * JD-Core Version:    0.6.2
 */
/*    */ package com.shahramjaved.notes.banknotes;
/*    */ 
/*    */ import com.shahramjaved.common.ChatUtil;
/*    */ import com.shahramjaved.common.ItemUtil;
/*    */ import com.shahramjaved.notes.Messages;
/*    */ import com.shahramjaved.notes.NotesPlugin;
/*    */ import net.milkbowl.vault.economy.Economy;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.Action;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class BankNoteListener
/*    */   implements Listener
/*    */ {
/* 16 */   private static Economy economy = NotesPlugin.instance.getEconomy();
/*    */ 
/*    */   @EventHandler
/*    */   public void onBankNoteUse(PlayerInteractEvent e) {
/* 20 */     Player player = e.getPlayer();
/* 21 */     ItemStack item = player.getItemInHand();
/*    */ 
/* 23 */     if (BankNoteItem.isBankNote(item)) {
/* 24 */       e.setCancelled(true);
/*    */ 
/* 26 */       if ((e.getAction() == Action.RIGHT_CLICK_BLOCK) || (e.getAction() == Action.RIGHT_CLICK_AIR)) {
/* 27 */         if (item.getAmount() > 1) {
/* 28 */           player.sendMessage(Messages.get("banknote-more-than-one"));
/* 29 */           return;
/*    */         }
/*    */ 
/* 32 */         int money = BankNoteItem.getMoneyStored(item);
/* 33 */         economy.depositPlayer(player, money);
/*    */ 
/* 35 */         ItemUtil.setItemInHandAir(player);
/*    */ 
/* 37 */         String consumeMsg = Messages.get("banknote-consume");
/* 38 */         consumeMsg = consumeMsg.replace("{amount}", ChatUtil.toCommaString(money));
/* 39 */         player.sendMessage(consumeMsg);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.notes.banknotes.BankNoteListener
 * JD-Core Version:    0.6.2
 */
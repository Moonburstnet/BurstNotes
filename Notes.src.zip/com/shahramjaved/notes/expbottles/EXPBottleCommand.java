/*    */ package com.shahramjaved.notes.expbottles;
/*    */ 
/*    */ import com.shahramjaved.common.ChatUtil;
/*    */ import com.shahramjaved.common.ExperienceUtil;
/*    */ import com.shahramjaved.common.InventoryUtil;
/*    */ import com.shahramjaved.notes.Messages;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class EXPBottleCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
/*    */   {
/* 16 */     if (!(sender instanceof Player)) {
/* 17 */       sender.sendMessage(Messages.get("must-be-player"));
/* 18 */       return false;
/*    */     }
/*    */ 
/* 21 */     Player player = (Player)sender;
/*    */ 
/* 23 */     if (cmd.getName().equalsIgnoreCase("bottle")) {
/* 24 */       if (args.length == 1) {
/*    */         try {
/* 26 */           int experience = Integer.parseInt(args[0]);
/*    */ 
/* 28 */           if (ExperienceUtil.getTotalExperience(player) >= experience) {
/* 29 */             ExperienceUtil.setTotalExperience(player, ExperienceUtil.getTotalExperience(player) - experience);
/* 30 */             InventoryUtil.addItemsOrDrop(player, new ItemStack[] { EXPBottleItem.createEXPBottle(player, experience) });
/*    */ 
/* 32 */             String bottleSuccessMsg = Messages.get("bottle-success");
/* 33 */             bottleSuccessMsg = bottleSuccessMsg.replace("{amount}", ChatUtil.toCommaString(experience));
/* 34 */             player.sendMessage(bottleSuccessMsg);
/*    */           } else {
/* 36 */             player.sendMessage(Messages.get("bottle-not-enough-exp"));
/*    */           }
/*    */         } catch (NumberFormatException e) {
/* 39 */           sender.sendMessage(Messages.get("not-valid-integer"));
/* 40 */           return false;
/*    */         }
/*    */       } else {
/* 43 */         player.sendMessage(Messages.get("bad-number-arguments"));
/* 44 */         player.sendMessage(Messages.get("bottle-usage"));
/*    */       }
/*    */     }
/*    */ 
/* 48 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.notes.expbottles.EXPBottleCommand
 * JD-Core Version:    0.6.2
 */
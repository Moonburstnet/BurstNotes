/*    */ package com.shahramjaved.notes.expbottles;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.shahramjaved.common.ItemUtil;
/*    */ import com.shahramjaved.nbt.NBTItem;
/*    */ import java.text.NumberFormat;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemFlag;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ 
/*    */ public final class EXPBottleItem
/*    */ {
/*    */   public static final String EXP_STORED_TAG = "ExperienceStored";
/*    */ 
/*    */   public static ItemStack createEXPBottle(Player player, int experience)
/*    */   {
/* 24 */     ItemStack bottle = new ItemStack(Material.EXP_BOTTLE, 1);
/* 25 */     ItemMeta meta = bottle.getItemMeta();
/* 26 */     meta.setDisplayName(ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "EXP");
/* 27 */     List lore = Lists.newArrayList();
/* 28 */     lore.add(ChatColor.LIGHT_PURPLE + "Signed: " + ChatColor.WHITE + player.getName());
/* 29 */     lore.add(ChatColor.LIGHT_PURPLE + "Amount: " + ChatColor.WHITE + NumberFormat.getInstance(Locale.US).format(experience));
/* 30 */     lore.add(ChatColor.DARK_GRAY + "[" + ChatColor.GRAY + "Right-Click" + ChatColor.DARK_GRAY + "]");
/* 31 */     meta.setLore(lore);
/* 32 */     meta.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ATTRIBUTES });
/* 33 */     bottle.setItemMeta(meta);
/*    */ 
/* 35 */     NBTItem nbt = new NBTItem(bottle);
/* 36 */     nbt.setInteger("ExperienceStored", Integer.valueOf(experience));
/*    */ 
/* 38 */     return nbt.getItem();
/*    */   }
/*    */ 
/*    */   public static boolean isStoredExperienceBottle(ItemStack item) {
/* 42 */     return (!ItemUtil.isItemEmpty(item)) && (new NBTItem(item).hasKey("ExperienceStored").booleanValue());
/*    */   }
/*    */ 
/*    */   public static int getExperienceStored(ItemStack bottle) {
/* 46 */     return new NBTItem(bottle).getInteger("ExperienceStored").intValue();
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.notes.expbottles.EXPBottleItem
 * JD-Core Version:    0.6.2
 */
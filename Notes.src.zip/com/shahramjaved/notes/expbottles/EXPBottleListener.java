/*    */ package com.shahramjaved.notes.expbottles;
/*    */ 
/*    */ import com.shahramjaved.common.ChatUtil;
/*    */ import com.shahramjaved.common.ExperienceUtil;
/*    */ import com.shahramjaved.common.ItemUtil;
/*    */ import com.shahramjaved.notes.Messages;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.Action;
/*    */ import org.bukkit.event.player.PlayerInteractAtEntityEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class EXPBottleListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onEXPBottleUse(PlayerInteractEvent e)
/*    */   {
/* 20 */     Player player = e.getPlayer();
/* 21 */     ItemStack item = player.getItemInHand();
/*    */ 
/* 23 */     if (EXPBottleItem.isStoredExperienceBottle(item)) {
/* 24 */       e.setCancelled(true);
/*    */ 
/* 26 */       if ((e.getAction() == Action.RIGHT_CLICK_BLOCK) || (e.getAction() == Action.RIGHT_CLICK_AIR)) {
/* 27 */         if (item.getAmount() > 1) {
/* 28 */           player.sendMessage(Messages.get("bottle-more-than-one"));
/* 29 */           return;
/*    */         }
/*    */ 
/* 32 */         int experience = EXPBottleItem.getExperienceStored(item);
/* 33 */         ExperienceUtil.setTotalExperience(player, ExperienceUtil.getTotalExperience(player) + experience);
/*    */ 
/* 35 */         ItemUtil.setItemInHandAir(player);
/*    */ 
/* 37 */         String bottleConsumeMsg = Messages.get("bottle-consume");
/* 38 */         bottleConsumeMsg = bottleConsumeMsg.replace("{amount}", ChatUtil.toCommaString(experience));
/* 39 */         player.sendMessage(bottleConsumeMsg);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
/*    */   public void onPlayerRightClick(PlayerInteractEntityEvent e) {
/* 46 */     Player player = e.getPlayer();
/* 47 */     if (EXPBottleItem.isStoredExperienceBottle(player.getItemInHand()))
/* 48 */       e.setCancelled(true);
/*    */   }
/*    */ 
/*    */   @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
/*    */   public void onPlayerRightClick(PlayerInteractAtEntityEvent e)
/*    */   {
/* 54 */     Player player = e.getPlayer();
/* 55 */     if (EXPBottleItem.isStoredExperienceBottle(player.getItemInHand()))
/* 56 */       e.setCancelled(true);
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.notes.expbottles.EXPBottleListener
 * JD-Core Version:    0.6.2
 */
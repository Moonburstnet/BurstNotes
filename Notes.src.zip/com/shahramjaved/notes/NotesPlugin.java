/*    */ package com.shahramjaved.notes;
/*    */ 
/*    */ import com.shahramjaved.notes.banknotes.BankNoteCommand;
/*    */ import com.shahramjaved.notes.banknotes.BankNoteListener;
/*    */ import com.shahramjaved.notes.expbottles.EXPBottleCommand;
/*    */ import com.shahramjaved.notes.expbottles.EXPBottleListener;
/*    */ import net.milkbowl.vault.economy.Economy;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.command.PluginCommand;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ import org.bukkit.plugin.RegisteredServiceProvider;
/*    */ import org.bukkit.plugin.ServicesManager;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class NotesPlugin extends JavaPlugin
/*    */ {
/* 12 */   private Economy econ = null;
/*    */   public static NotesPlugin instance;
/*    */ 
/*    */   public void onEnable()
/*    */   {
/* 17 */     instance = this;
/*    */ 
/* 19 */     saveDefaultConfig();
/* 20 */     setupVault();
/*    */ 
/* 22 */     Messages.load();
/*    */ 
/* 24 */     getServer().getPluginManager().registerEvents(new EXPBottleListener(), this);
/* 25 */     getCommand("bottle").setExecutor(new EXPBottleCommand());
/*    */ 
/* 27 */     getServer().getPluginManager().registerEvents(new BankNoteListener(), this);
/* 28 */     getCommand("banknote").setExecutor(new BankNoteCommand());
/*    */   }
/*    */ 
/*    */   private boolean setupVault() {
/* 32 */     if (getServer().getPluginManager().getPlugin("Vault") == null) {
/* 33 */       return false;
/*    */     }
/* 35 */     RegisteredServiceProvider rsp = getServer().getServicesManager().getRegistration(Economy.class);
/* 36 */     if (rsp == null) {
/* 37 */       return false;
/*    */     }
/* 39 */     this.econ = ((Economy)rsp.getProvider());
/* 40 */     return this.econ != null;
/*    */   }
/*    */ 
/*    */   public Economy getEconomy() {
/* 44 */     return this.econ;
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.notes.NotesPlugin
 * JD-Core Version:    0.6.2
 */
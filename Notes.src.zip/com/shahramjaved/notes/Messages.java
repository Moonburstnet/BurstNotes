/*    */ package com.shahramjaved.notes;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.configuration.ConfigurationSection;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ 
/*    */ public final class Messages
/*    */ {
/* 12 */   private static final FileConfiguration config = NotesPlugin.instance.getConfig();
/*    */ 
/* 14 */   private static final Map<String, String> messages = new HashMap();
/*    */ 
/*    */   public static void load()
/*    */   {
/* 20 */     ConfigurationSection section = config.getConfigurationSection("messages");
/* 21 */     for (String msg : section.getKeys(false))
/* 22 */       messages.put(msg, ChatColor.translateAlternateColorCodes('&', config.getString("messages." + msg)));
/*    */   }
/*    */ 
/*    */   public static String get(String key)
/*    */   {
/* 27 */     return (String)messages.get(key);
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Downloads\Notes.jar
 * Qualified Name:     com.shahramjaved.notes.Messages
 * JD-Core Version:    0.6.2
 */